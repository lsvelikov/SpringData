package org.example;

import jakarta.persistence.Enumerated;

public enum CardType {
    SILVER, GOLD, PLATINUM
}
