package com.example.jasonexe.util;

public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
