package com.example.jasonexe.costant;

public class GlobalConstant {
    public final static String RESOURCES_FILES_PATH = "src/main/resources/files/";
}
