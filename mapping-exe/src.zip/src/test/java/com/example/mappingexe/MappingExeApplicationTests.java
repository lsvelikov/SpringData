package com.example.mappingexe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MappingExeApplicationTests {

    @Test
    void contextLoads() {
    }

}
