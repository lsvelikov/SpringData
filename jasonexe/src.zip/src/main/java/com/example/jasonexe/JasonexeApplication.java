package com.example.jasonexe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JasonexeApplication {

    public static void main(String[] args) {
        SpringApplication.run(JasonexeApplication.class, args);
    }

}
