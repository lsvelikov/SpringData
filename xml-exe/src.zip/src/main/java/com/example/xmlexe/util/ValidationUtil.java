package com.example.xmlexe.util;

public interface ValidationUtil {

    <T> boolean isValid(T entity);
}
