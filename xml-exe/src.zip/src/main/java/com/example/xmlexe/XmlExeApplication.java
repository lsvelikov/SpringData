package com.example.xmlexe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlExeApplication {

    public static void main(String[] args) {
        SpringApplication.run(XmlExeApplication.class, args);
    }

}
